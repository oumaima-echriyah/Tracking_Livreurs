module com.example.tracking_l {
    requires javafx.controls;
    requires javafx.fxml;
    requires mysql.connector.j;
    requires java.sql;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;

    opens com.example.tracking_l to javafx.fxml;
    exports com.example.tracking_l;
}